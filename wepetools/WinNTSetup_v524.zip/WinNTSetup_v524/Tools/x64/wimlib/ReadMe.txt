Put "libwim-15.dll" from "https://wimlib.net/" here,
if you want to enable wimlib features in WinNTSetup.

You can add following to the ini file, to set wimlib as default

[Options]
UseWimLIB=1